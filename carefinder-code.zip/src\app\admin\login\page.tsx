'use client'

import { useState } from 'react'

import { Eye, EyeOff, LogIn } from 'lucide-react'
import { getBrowserClient } from '@/lib/supabase/browser'

export default function AdminLoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email || !password) {
      setError('Please enter your email and password')
      return
    }

    setLoading(true)
    setError('')

    try {
      const supabase = getBrowserClient()

      const { data, error: authError } = await supabase.auth.signInWithPassword(
        {
          email,
          password,
        }
      )

      if (authError) {
        setError('Invalid email or password')
        setLoading(false)
        return
      }

      // Verify the user is an admin before redirecting
      const role =
        data.user?.app_metadata?.role ?? data.user?.user_metadata?.role

      if (role !== 'admin') {
        setError('You do not have admin access')
        await supabase.auth.signOut()
        setLoading(false)
        return
      }

      // Wait for session to be fully written before redirect
      await new Promise((resolve) => setTimeout(resolve, 1000))
      window.location.replace('/admin/dashboard')
    } catch (err) {
      console.error(err)
      setError('Something went wrong. Please try again.')
      setLoading(false)
    }
  }
  return (
    <div
      className="min-h-screen flex items-center justify-center px-4"
      style={{
        background: 'linear-gradient(135deg, #0D1B2A 0%, #1A2D42 100%)',
      }}
    >
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div
            className="inline-flex items-center justify-center w-12 h-12 rounded-2xl mb-4"
            style={{
              background: 'var(--accent)',
              boxShadow: '0 4px 20px rgba(91,80,240,0.4)',
            }}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path
                d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"
                fill="white"
                fillOpacity={0.3}
                stroke="white"
                strokeWidth="1.5"
              />
              <path
                d="M9.5 8.5C9.5 7.67 10.17 7 11 7c.44 0 .84.18 1.13.47L12 7.33l-.13.14A1.5 1.5 0 0 1 13 7c.83 0 1.5.67 1.5 1.5 0 1.66-2.5 3.5-2.5 3.5S9.5 10.16 9.5 8.5z"
                fill="white"
              />
            </svg>
          </div>
          <h1
            className="text-2xl font-bold text-white"
            style={{ fontFamily: 'Sora, sans-serif' }}
          >
            Admin Login
          </h1>
          <p
            className="text-sm mt-1"
            style={{ color: 'rgba(255,255,255,0.5)' }}
          >
            Carefinder Admin Dashboard
          </p>
        </div>

        {/* Form */}
        <div
          className="rounded-2xl p-6"
          style={{
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
            boxShadow: 'var(--shadow-lg)',
          }}
        >
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <label
                className="block text-xs font-semibold mb-1.5"
                style={{ color: 'var(--fg-muted)' }}
              >
                Email address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@carefinder.ng"
                className="input-base"
                aria-label="Email address"
                autoComplete="email"
              />
            </div>

            <div>
              <label
                className="block text-xs font-semibold mb-1.5"
                style={{ color: 'var(--fg-muted)' }}
              >
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="input-base pr-10"
                  aria-label="Password"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? (
                    <EyeOff size={16} style={{ color: 'var(--fg-subtle)' }} />
                  ) : (
                    <Eye size={16} style={{ color: 'var(--fg-subtle)' }} />
                  )}
                </button>
              </div>
            </div>

            {error && (
              <p
                className="text-xs px-3 py-2 rounded-lg"
                style={{ background: '#FEE2E2', color: '#DC2626' }}
                role="alert"
              >
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full justify-center py-3 mt-1"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <svg
                    className="animate-spin"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <circle
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="white"
                      strokeOpacity={0.3}
                      strokeWidth="3"
                    />
                    <path
                      d="M12 2a10 10 0 0 1 10 10"
                      stroke="white"
                      strokeWidth="3"
                      strokeLinecap="round"
                    />
                  </svg>
                  Signing in...
                </span>
              ) : (
                <>
                  <LogIn size={14} />
                  Sign in
                </>
              )}
            </button>
          </form>
        </div>

        <p
          className="text-center text-xs mt-4"
          style={{ color: 'rgba(255,255,255,0.3)' }}
        >
          Admin access only · Public users don&apos;t need an account to search
        </p>
      </div>
    </div>
  )
}
